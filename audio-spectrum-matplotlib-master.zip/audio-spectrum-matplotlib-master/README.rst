This Gist is about how I use PyAudio, NumPy, and Matplotlib to plot freqency spectrum of system sound or microphone.

You can read this `blog post`_ for more detail or watch `this video`__:

.. _blog post: https://yjlv.blogspot.com/2012/11/frequency-spectrum-of-sound-using.html
__ video_
.. _video: https://www.youtube.com/watch?v=hiGB_AP6iTo

.. figure:: https://i.ytimg.com/vi/hiGB_AP6iTo/maxresdefault.jpg
   :target: video_
